let student = [
    { name: 'Sayket', id: 11 },
    { name: 'Mahmodul', id: 12 },
    { name: 'Sakib', id: 13 },
    { name: 'Nahid', id: 14 },
    { name: 'Sumon', id: 15 },
    { name: 'Rayhan', id: 16 },
    { name: 'Avir', id: 17 },
    { name: 'Mahin', id: 18 },
    { name: 'Ali', id: 19 }
];
export default student;