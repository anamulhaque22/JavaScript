import React from 'react';

const AddProductPage = () => {
    return (
        <div>
            <h1>Add</h1>
        </div>
    );
};

export default AddProductPage;